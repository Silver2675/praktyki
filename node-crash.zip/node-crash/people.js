const people = ['Alice', 'Bob', 'Charlie', 'David', 'Eve'];
const ages = [25, 30, 35, 40, 45];

console.log('People:', people);

module.exports = {
    people: people,
    ages: ages,
};